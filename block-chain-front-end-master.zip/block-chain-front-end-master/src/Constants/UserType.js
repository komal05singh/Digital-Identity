export default USER_TYPE = {
  viewer: "viewer",
  issuer: "issuer",
  varifier: "varifier",
};
